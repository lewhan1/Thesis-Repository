/*
 * optype.c
 *
 *  Created on: Sep 14, 2025
 *      Author: User
 */
#include "optype.h"

bool Check_Op_Type(uint8_t operation){

	bool is_auto = false;

	if (operation == 0){
		is_auto =  false;
	}
	else if (operation == 1){
		is_auto =  true;
	}
	return is_auto;
}

void Init_Auto(){

}

void Init_Teleop(){

}

