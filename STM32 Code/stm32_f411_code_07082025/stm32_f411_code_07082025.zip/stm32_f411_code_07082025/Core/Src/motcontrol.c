/*
 * motcontrol.c
 *
 *  Created on: Sep 14, 2025
 *      Author: User
 */
#include "motcontrol.h"

void Set_Mot_Duty(int16_t right_duty, int16_t left_duty){ //Set motor speed using PWM

	htim1.Instance->CCR1 = abs(right_duty);
	htim1.Instance->CCR2 = abs(left_duty);
}

void Set_Mot_Direc(int16_t right_speed, int16_t left_speed){ //Set motor direction
	if (left_speed > 0){
		HAL_GPIO_WritePin(BIN1_GPIO_Port, BIN1_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(BIN2_GPIO_Port, BIN2_Pin, GPIO_PIN_RESET);
	}
	else if(left_speed<0){
		HAL_GPIO_WritePin(BIN1_GPIO_Port, BIN1_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(BIN2_GPIO_Port, BIN2_Pin, GPIO_PIN_SET);
	}
	if (right_speed > 0){
		HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
	}
	else if(right_speed<0){
		HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_SET);
	}
	else if (right_speed  == 0){
		HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
	}
	else if (left_speed == 0){
		HAL_GPIO_WritePin(BIN2_GPIO_Port, BIN2_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(BIN1_GPIO_Port, BIN1_Pin, GPIO_PIN_RESET);
	}
}

void Update_Motors(){ //Update the motor PWM with PID
	float l_setpoint = leftPID.setpoint;
	float r_setpoint = rightPID.setpoint;

	float left_output = Do_Pid(&leftPID, l_setpoint, left_encoder.velocity);
	float right_output = Do_Pid(&rightPID, r_setpoint, right_encoder.velocity);

	//uint8_t left_duty = (uint8_t)((left_output + 151.47) / 40.206);
	//uint8_t right_duty = (uint8_t)((right_output + 151.47) / 40.206);
	int16_t left_duty = (int16_t) left_output;
	int16_t right_duty = (int16_t) right_output;

	/*if(left_duty > 100) left_duty = 100;
	else if(left_duty < -100) left_duty = -100;

	if(right_duty > 100) right_duty = 100;
	else if(right_duty < -100) right_duty = -100;*/

	Set_Mot_Duty(right_duty, left_duty);
	Set_Mot_Direc(right_duty, left_duty);
}








