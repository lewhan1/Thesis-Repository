/*
 * odometry.c
 *
 *  Created on: Sep 14, 2025
 *      Author: User
 */
#include "odometry.h"


#define TICKS_PER_REV 900 //encoder ticks for one rotation

// Odometry state (persistent)
static float x = 0.0f;
static float y = 0.0f;
static float yaw = 0.0f;

static int32_t last_left_position = 0; //initialise motor pos
static int32_t last_right_position = 0;
//convert encoder velocity to odemetry
void Ticks_to_Odom(float left_curr_velocity, int32_t left_curr_position,
                    float right_curr_velocity, int32_t right_curr_position,
                    float dt, odom_data_t *odom) {

    float wheel_radius = 0.0325f; //robot sepcs
    float base_radius  = 0.0835f;

    //Distance per tick
    float distance_per_tick = (2.0f * M_PI * wheel_radius) / TICKS_PER_REV;

    last_left_position  = left_curr_position;
    last_right_position = right_curr_position;


    //Linear velocities
    float vL = left_curr_velocity  * distance_per_tick;
    float vR = right_curr_velocity * distance_per_tick;

    //Robot linear and angular velocity
    odom->linear_velocity  = (vR + vL) / 2.0f;
    odom->angular_velocity = (vR - vL) / (2.0f * base_radius);

    //Integration for displacement
    float delta_s = odom->linear_velocity * dt;
    float delta_theta = odom->angular_velocity * dt;

    x   += delta_s * cosf(yaw + delta_theta / 2.0f); //odom cal from cordinate plane
    y   += delta_s * sinf(yaw + delta_theta / 2.0f);
    yaw += delta_theta;

    //Normalize yaw angle
    if (yaw > M_PI) yaw -= 2.0f * M_PI;
    if (yaw < -M_PI) yaw += 2.0f * M_PI;

    //Store pose to struct
    odom->x = x;
    odom->y = y;
    odom->yaw = yaw;
}
