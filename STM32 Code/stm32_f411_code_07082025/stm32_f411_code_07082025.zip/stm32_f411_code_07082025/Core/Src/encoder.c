/*
 * encoder.c
 *
 *  Created on: Sep 14, 2025
 *      Author: User
 */
#include "encoder.h"

//Update motor velocity and position
void Get_Mot_Velocity(encoder_instance *encoder, TIM_HandleTypeDef *htim, float dt){
    uint16_t temp_count = __HAL_TIM_GET_COUNTER(htim);
    static uint8_t first_time = 0;

    if(!first_time){
        encoder->velocity = 0;
        encoder->last_counter_value = temp_count;
        first_time = 1;
        return;
    }
    //Difference of tick counts
    int32_t diff = ((int32_t)temp_count - (int32_t)encoder->last_counter_value);
    //Timer maximum value
    int32_t arr = (int32_t)htim->Instance->ARR;

    //Handle overflow or underflow of timer
    if(diff > arr / 2) diff -= (arr + 1);
    else if(diff < -arr / 2) diff += (arr + 1);

    encoder->velocity = (float)diff/dt; //Velocity from dividing by time
    encoder->position += diff;          //Angular displacement
    encoder->last_counter_value = temp_count;
}

//Reset motor encoder
void Reset_Encoder(encoder_instance *encoder, TIM_HandleTypeDef *htim){
    __HAL_TIM_SET_COUNTER(htim, 0);
    encoder->velocity = 0;
    encoder->position = 0;
    encoder->last_counter_value = 0;
}
