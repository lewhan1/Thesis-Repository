/*
 * diffdrive.c
 *
 *  Created on: Sep 16, 2025
 *      Author: User
 */
#include "diffdrive.h"

void Vel_to_Ticks(){
	float wheel_radius = 0.0325;
	float base_radius = 0.0835;
	float V = twist_msg.linearVx;
	float W = twist_msg.angularVz;

	float V_r = V + (base_radius * W / 2); //ros twist uses CCW as +
	float V_l = V - (base_radius * W / 2);

	float W_r = V_r/wheel_radius;
	float W_l = V_l/wheel_radius;

	//for ticks per second
	float ticks_r = W_r*900.0/(2*M_PI);
	float ticks_l = W_l*900.0/(2*M_PI);

	rightPID.setpoint = ticks_r;
	leftPID.setpoint = ticks_l;

}


