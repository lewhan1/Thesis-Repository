/*
 * pidcontoroller.c
 *
 *  Created on: Sep 15, 2025
 *      Author: User
 */
#include "pidcontroller.h"

#define MAX_PWM 100
#define MIN_PWM -100

void Init_PID(PID_controller *pid, float Kp, float Ki, float Kd){ //Initialize PID
	pid->Kp = Kp;
	pid->Ki = Ki;
	pid->Kd = Kd; //PID gains

	pid->setpoint = 0; //set velocity
	pid->prevsetpoint = 0; //prev velocity
	pid->measurement = 0;
	pid->prevmeasurement = 0;
	pid->error = 0;
	pid->prevError = 0;

	pid->propotional = 0; //pid values
	pid->derivative = 0;
	pid->integral = 0;
	pid->output = 0;
}

float Do_Pid(PID_controller *pid, float set_velocity, float curr_velocity){
	pid->setpoint = set_velocity;
	pid->measurement = curr_velocity;

	if (pid->setpoint == 0){
		pid->integral = 0;
	}

	pid->error = set_velocity - curr_velocity;
	pid->integral += pid->error; //Integral error
	pid->propotional = pid->error; //Proportional error
	pid->derivative = pid->error - pid->prevError; //Derivative error

	//PID output calculations
	pid->output = pid->Kp * pid->propotional + pid->Kd * (pid->derivative) + pid->Ki *pid->integral;

	//PID output clipping
	if (pid->output > MAX_PWM) pid->output = MAX_PWM;
	else if (pid->output < MIN_PWM) pid->output = MIN_PWM;

	float output = pid->output;
	pid->prevError = pid->error;
	pid->prevsetpoint = pid->setpoint;

	return output;
}





