/*
 * odometry.h
 *
 *  Created on: Sep 14, 2025
 *      Author: User
 */

#ifndef INC_ODOMETRY_H_
#define INC_ODOMETRY_H_

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include "main.h"
#include <math.h>

typedef struct {
    float x;               // meters
    float y;               // meters
    float yaw;             // radians
    float linear_velocity; // m/s
    float angular_velocity; // rad/s
} odom_data_t;

void Ticks_to_Odom(float left_curr_velocity, int32_t left_curr_position,
                    float right_curr_velocity, int32_t right_curr_position,
                    float dt, odom_data_t *odom);

#endif /* INC_ODOMETRY_H_ */
