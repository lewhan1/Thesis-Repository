/*
 * motcontrol.h
 *
 *  Created on: Sep 14, 2025
 *      Author: User
 */

#ifndef INC_MOTCONTROL_H_
#define INC_MOTCONTROL_H_

#include <stdint.h>
#include "stm32f4xx_hal.h"
#include "main.h"
#include "encoder.h"
#include "pidcontroller.h"
#include <stdlib.h>

extern encoder_instance right_encoder;
extern encoder_instance left_encoder;
extern PID_controller rightPID;
extern PID_controller leftPID;

extern TIM_HandleTypeDef htim1;

void Set_Mot_Duty(int16_t right_duty, int16_t left_duty);
void Set_Mot_Direc(int16_t right_speed, int16_t left_speed);
void Update_Motors();


#endif /* INC_MOTCONTROL_H_ */
