/*
 * pidcontroller.h
 *
 *  Created on: Sep 15, 2025
 *      Author: User
 */

#ifndef INC_PIDCONTROLLER_H_
#define INC_PIDCONTROLLER_H_

#include <stdint.h>
#include "main.h"
#include "stm32f4xx_hal.h"
#include "math.h"

typedef struct{ //PID struct
	float Kp; //gains
	float Ki;
	float Kd;

	float setpoint; //set velocity
	float prevsetpoint;
	float measurement;
	float prevmeasurement;
	float error;

	float prevError;

	float propotional; //PIDvalues
	float derivative;
	float integral;

	float output; //PID output
}PID_controller;

extern PID_controller rightPID;
extern PID_controller leftPID;

void Init_PID(PID_controller *pid, float Kp, float Ki, float Kd);
float Do_Pid(PID_controller *pid, float set_velocity, float curr_velocity);


#endif /* INC_PIDCONTROLLER_H_ */
