/*
 * optype.h
 *
 *  Created on: Sep 14, 2025
 *      Author: User
 */

#ifndef INC_OPTYPE_H_
#define INC_OPTYPE_H_

#include <stdbool.h>
#include <stdint.h>

bool Check_Op_Type(uint8_t operation);
void Init_Auto(void);
void Init_Teleop(void);


#endif /* INC_OPTYPE_H_ */
