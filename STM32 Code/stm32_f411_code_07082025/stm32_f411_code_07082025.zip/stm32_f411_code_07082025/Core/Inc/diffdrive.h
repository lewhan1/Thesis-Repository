/*
 * diffdrive.h
 *
 *  Created on: Sep 16, 2025
 *      Author: User
 */

#ifndef INC_DIFFDRIVE_H_
#define INC_DIFFDRIVE_H_

#include <stdint.h>
#include "stm32f4xx_hal.h"
#include "main.h"
#include "encoder.h"
#include "pidcontroller.h"
#include "math.h"

typedef struct{ //struct for twist
	float linearVx;
	float angularVz;
}cmd_vels;


extern PID_controller rightPID;
extern PID_controller leftPID;
extern cmd_vels twist_msg;

void Vel_to_Ticks();

#endif /* INC_DIFFDRIVE_H_ */
