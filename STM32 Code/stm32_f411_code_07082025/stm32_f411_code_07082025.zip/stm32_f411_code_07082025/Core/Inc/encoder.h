/*
 * encoder.h
 *
 *  Created on: Sep 14, 2025
 *      Author: User
 */

#ifndef INC_ENCODER_H_
#define INC_ENCODER_H_

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include "main.h"


typedef struct{ //struct for encoder data
	float velocity;
	int32_t position;
	uint16_t last_counter_value;
} encoder_instance;

void Get_Mot_Velocity(encoder_instance *encoder, TIM_HandleTypeDef *htim, float dt);
void Reset_Encoder(encoder_instance *encoder, TIM_HandleTypeDef *htim);

#endif /* INC_ENCODER_H_ */
